<?= $this->extend("layout/default"); ?>

<?= $this->section("title"); ?>Task<?= $this->endSection(); ?>

<?= $this->section("content"); ?>

<h1>Task</h1>

<a href=<?= site_url("/task/new") ?> >New Task</a>

<ul>
    <?php foreach ($tasks as $task) : ?>
        <li>
            <a href=<?=site_url("/show/". $task['id'] )?>>
                <?= $task['description'] ?>
            </a>
        </li>
    <?php endforeach; ?>
</ul>


<?= $this->endSection(); ?>