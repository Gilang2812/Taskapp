

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title><?= $this->renderSection("title"); ?></title>
  </head>

  <body><?php if(session()->has('info')): ?>
    <div class="info">
      <?= session('info') ?>
    </div>



    <?php endif; ?>

    <?= $this->renderSection("content"); ?>
  </body>
</html>