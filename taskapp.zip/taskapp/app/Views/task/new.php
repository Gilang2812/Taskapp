<?= $this->extend("layout/default"); ?>

<?= $this->section("title"); ?>New <?= $this->endSection(); ?>

<?= $this->section("content"); ?>

<h1>New task</h1>

<?php if (session()->has('error')) : ?>
    <ul>
        <?php foreach (session('error') as $error) : ?>
            <li><?= $error ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>

<?= form_open("/task/create") ?>

<div>
    <label for="description">Description</label>
    <input type="text" name="description" id="description" value="" >
</div>

<button>Save</button>
<a href=<?= site_url("/task") ?>>cancel</a>


</form>

<?= $this->endSection(); ?>