<?= $this->extend("layout/default"); ?>

<?= $this->section("title"); ?>Home<?= $this->endSection(); ?>

<?= $this->section("content"); ?>

<h1>Welcome</h1>

<ul>
    <li>
        <a href="/task">START</a>
    </li>
</ul>

<?= $this->endSection(); ?>
