<?= $this->extend("layout/default"); ?>

<?= $this->section('title'); ?>show <?= $this->endSection(); ?>

<?= $this->section('content'); ?>
<h1>Task</h1>

<a href=<?= site_url("/task") ?> >&laquo; back to index</a>

<dl>
    <dt>ID</dt>
    <dd><?= $task['id'] ?></dd>

    <dt>Description</dt>
    <dd><?= $task['description'] ?></dd>

</dl>

<a href="<?= site_url('/task/update/'.$task['id'])?>">edit</a>

<?= $this->endSection(); ?>