<?php

namespace App\Controllers;

class TaskController extends BaseController
{
    public function index()
    {

        $model = new \App\Models\TaskModel;
        $data = $model->findAll();

        return view("task/index", ['tasks' => $data]);
    }

    public function show($id)
    {

        $model = new \App\Models\TaskModel;
        $task = $model->find($id);

        return view('task/show', [
            'task' => $task
        ]);
    }

    public function new()
    {
        return view("task/new");
    }

    public function create()
    {
        $model = new \App\Models\TaskModel;

        $result = $model->insert([
            'description' => $this->request->getPost("description")
        ]);

        if ($result == false) {

            return redirect()->back()
                ->with('error', $model->error());
        } else {

            return redirect()->to("show/$result")
                ->with('info', 'Task created successfully');
        }
    }

    public function edit($id)
    {
        $model = new \App\Models\TaskModel;
        $task = $model->find($id);

        return view('task/edit', [
            'task' => $task
        ]);
    }

    public function update($id)
    {
        $model = new \App\Models\TaskModel;

        $model->update($id, [
            'description' => $this->request->getPost('description')
        ]);

        return redirect()->to("show/$id")
                         ->with('info', 'task updated successfully');
    }
}
