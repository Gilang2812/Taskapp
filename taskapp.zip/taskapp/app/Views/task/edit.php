<?= $this->extend("layout/default"); ?>

<?= $this->section("title"); ?>edit <?= $this->endSection(); ?>

<?= $this->section("content"); ?>

<h1>New task</h1>

<?php if (session()->has('error')) : ?>
    <ul>
        <?php foreach (session('error') as $error) : ?>
            <li><?= $error ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>

<?= form_open("/task/update/".$task['id']) ?>

<div>
    <label for="description">Description</label>
    <input type="text" name="description" id="description" value="<?=$task['description']?>" >
</div>

<button>Save</button>
<a href=<?= site_url("/show/".$task['id']) ?>>cancel</a>


</form>

<?= $this->endSection(); ?>